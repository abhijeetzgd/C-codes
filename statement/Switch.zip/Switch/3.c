//Mathing Case

#include<stdio.h>
void main(){
    int a=1;
  switch(a){
    case 1:
          printf("Inside Switch\n" );
  }
  printf("outside switch\n" );
}
/*
abhijeetzgd@abhijeetzgd-ThinkPad-E490:~/c/statement/Switch$ ./a.out
Inside Switch
outside switch

*/
