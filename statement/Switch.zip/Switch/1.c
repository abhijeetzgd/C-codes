#include<stdio.h>
void main(){
  
  switch(){

  }
}
/*
abhijeetzgd@abhijeetzgd-ThinkPad-E490:~/c/statement/Switch$ cc 1.c
1.c: In function ‘main’:
1.c:4:10: error: expected expression before ‘)’ token
   switch(){
          ^
*/
