#include<stdio.h>
void main(){

  int a=20;
  int b=30;
  switch(a){
    case 20:
    printf("Twenty\n" );
    break;
  }

  switch(b){
    case 30:
    printf("Thirty\n" );
    break;
  }
}
