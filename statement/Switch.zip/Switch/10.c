#include<stdio.h>
 int main(int argc, char const *argv[]) {
  int a=65;
  switch(a){
    case'A':
    printf("Character\n" );
    break;
  }

  printf("Outside switch\n" );
  return 0;
}
