#include<stdio.h>

void main(){

  int a=10;

  else{
    printf("Both are sam\n" );
  }
}
/*abhijeetzgd@abhijeetzgd-ThinkPad-E490:~/c/statement/IfElseError$ cc 1.c
1.c: In function ‘main’:
1.c:7:3: error: ‘else’ without a previous ‘if’
   else{
   ^~~~
*/
