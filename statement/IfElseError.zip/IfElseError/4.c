#include<stdio.h>

void main(){

  int a=10;

  if (a==10){
    printf("a is greater\n" );
  }
  else if(a>10){
    printf("a is greater\n");
  }
}
/*
abhijeetzgd@abhijeetzgd-ThinkPad-E490:~/c/statement/IfElseError$ ./a.out
a is greater
*/
