#include<stdio.h>

void main(){

  int a=10;

if  else{
    printf("Both are sam\n" );
  }
}
/*
abhijeetzgd@abhijeetzgd-ThinkPad-E490:~/c/statement/IfElseError$ cc 2.c
2.c: In function ‘main’:
2.c:7:5: error: expected ‘(’ before ‘else’
 if  else{
     ^~~~
*/
