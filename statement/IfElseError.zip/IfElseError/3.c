#include<stdio.h>

void main(){

  int a=10;

else if{
    printf("Both are sam\n" );
  }
}
/*
abhijeetzgd@abhijeetzgd-ThinkPad-E490:~/c/statement/IfElseError$ cc 3.c
3.c: In function ‘main’:
3.c:7:1: error: ‘else’ without a previous ‘if’
 else if{
 ^~~~
3.c:7:8: error: expected ‘(’ before ‘{’ token
 else if{
        ^
*/
