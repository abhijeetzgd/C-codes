#include<stdio.h>
void main(){

  int arr[]={10,20,30,40,50};

  int arr1[3][3] = {1,2,3,4,5,6,7,8,9};

  printf("%d\n",2[arr]);

  printf("%d\n",0[arr1][2]);
  printf("%d\n",1[arr1][0]);
  printf("%d\n",2[arr1][1]);


}
