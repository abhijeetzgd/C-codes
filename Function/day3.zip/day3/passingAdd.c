#include<stdio.h>
int sum=0;

void elePass(int x){
  for(int i=0;i<5;i++){
      
  }

}

void main(){

  int arr[]={1,2,3,4,5};
  int n = 5;

  elePass(&arr[i],n);

  printf("sum = %d\n",sum);

}
