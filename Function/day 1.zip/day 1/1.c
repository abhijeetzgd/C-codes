#include<stdio.h>


void ipl(){

printf("IN IPL\n")  ;
}

void main(){

  ipl();
}
/*
redefination of ipl
void ipl(){

printf("IN IPL\n")  ;
}
ekach gharamadhe same navache manus errror.
*/
