//printf cha prototype ahe #include madhe
//#include<stdio.h>
int  printf(const char *,...);
void ipl();

void main(){

  ipl();
}

void ipl(){
int a =  printf("IN IPL 2020\n");
printf("%d\n",a);
}
