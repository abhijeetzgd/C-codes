#include<stdio.h>
void ipl();
void main(){

  ipl();
}

void ipl(){
  printf("IN IPL 2020\n");
}
