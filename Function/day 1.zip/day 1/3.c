//ipl chi defination nhi dili

#include<stdio.h>
void ipl();
void main(){

  ipl();
}
/*
void ipl(){
  printf("IN IPL 2020\n");
}
*/

/*
Error
/tmp/ccml45Ok.o: In function `main':
3.c:(.text+0xa): undefined reference to `ipl'
collect2: error: ld returned 1 exit status
*/
