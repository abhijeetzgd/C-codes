#include<stdio.h>
void main(){
  int a=12,b=0;
  a=++a + ++a;

  printf("%d \n",a);

}
//28
