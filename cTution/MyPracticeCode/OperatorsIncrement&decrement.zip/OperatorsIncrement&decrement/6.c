#include<stdio.h>
void main(){
  int a=12,b=14;
  b=a++ + ++b;

  printf("%d \n",b);//27

  

}
