#include<stdio.h>
void main(){

  int x=240,ans;
  ans =x>>4;
  printf("%d\n",ans);
}
