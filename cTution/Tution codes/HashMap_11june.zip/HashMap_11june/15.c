#include<stdio.h>
void main(){
/*
  int a=12,34,6,7,89;//errror
  printf("%d\n", a);
*/
int u=(1,2,3,4,5,6);//last value will be updated
printf("%d\n", u);

}
