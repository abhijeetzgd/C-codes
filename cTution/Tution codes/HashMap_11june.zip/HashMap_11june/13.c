#include<stdio.h>
void main(){

  int x=10;// 0 0 0 0 1 0 1 0
  int y=15;
  int ans=0;//0 0 0 0 1 1 1 1

  

  ans = x^y;

  printf("%d\n",ans );

}
