#include<stdio.h>
void main(){

  int a=00 ,b=01,ans;
  ans=a|b;
  printf("%d\n",ans);

}
