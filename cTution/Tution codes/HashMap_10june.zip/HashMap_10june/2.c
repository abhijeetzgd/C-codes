#include<stdio.h>
void main(){

  int x=10,y=15,ans;

  ans=x|y;

  printf("%d",ans);
}
