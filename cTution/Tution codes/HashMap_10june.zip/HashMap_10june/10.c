#include<stdio.h>
void main(){

  int a=111 ,b=010,c=011,ans;
  ans=a|b;
printf("ans=%d\n",ans);
  ans = ans<<3;
printf("Lft shift answer by 3\n");
printf("%d\n",ans);
}
