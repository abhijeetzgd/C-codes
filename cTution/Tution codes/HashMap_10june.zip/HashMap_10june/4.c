#include<stdio.h>
void main(){

  int a=10 ,b=11,ans;
  ans=a|b;
  printf("%d\n",ans);

}
