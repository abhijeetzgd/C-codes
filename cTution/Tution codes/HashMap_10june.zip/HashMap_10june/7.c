#include<stdio.h>
void main(){

  int a=000 ,b=000,c=111,ans;
  ans=a|b|c;
  printf("%d\n",ans);

}
