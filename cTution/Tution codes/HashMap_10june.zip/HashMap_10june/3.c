#include<stdio.h>
void main(){

  int x=10;
  int ans =0;

  ans = x<<2;

x=15;
ans =x<<3;
  printf("%d\n",ans);//40
}
