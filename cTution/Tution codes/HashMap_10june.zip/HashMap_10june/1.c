#include<stdio.h>
void main(){

  int x=10;
  int y=15,ans=0;

  ans =x&y;

  printf("%d\n",ans);
}
