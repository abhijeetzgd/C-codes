#include<stdio.h>
void main(){

      int i=10;
      do{

        printf("IN do while body\n" );
        i++;

      }while(i > 20);

      printf("out of while\n" );
}
