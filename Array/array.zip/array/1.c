#include<stdio.h>
void main(){

  int Stud_age [5] = {19,20,22,21,30,0};
  int stud_grade [4] = {'A','B','C','D'};
  float stud_sal [3] = {10.45,8.5,14.30};


}
/*
1.c: In function ‘main’:
1.c:4:38: warning: excess elements in array initializer
   int Stud_age [5] = {19,20,22,21,30,0};
                                      ^
1.c:4:38: note: (near initialization for ‘Stud_age’)
*/
