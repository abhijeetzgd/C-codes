#include<stdio.h>
void main(){

  int jerNo[5] = {11,7,45,12,10};

  float avg []= {49.90,54.30,45.50,47.54,50.52};
  int run[5];
  int x = 10;

printf("%d\n",jerNo[3] );   //12
printf("%f\n",avg[3] );   //12
printf("%d\n",run[3] );   //12

}
