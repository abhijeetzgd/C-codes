#include<stdio.h>
void main(){

//  char a[5];
  float f[5];
  //printf("%c\n",a[3] );
  printf("%f\n",f[3] );

}
